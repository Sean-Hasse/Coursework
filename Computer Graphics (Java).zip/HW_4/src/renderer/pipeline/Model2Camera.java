/*

*/

package renderer.pipeline;
import  renderer.scene.*;

import java.util.List;

/**
   Transform each {@link Vertex} of a {@link Model} from the
   model's (private) local coordinate system to the (shared)
   {@link Camera} coordinate system.
<p>
   For each {@code Vertex} object in a {@code Model} object,
   use a {@link Position}'s model {@link Matrix} to transform the
   {@code Vertex} object's coordinates from the model's coordinate
   system to the camera coordinate system.
*/
public class Model2Camera
{
   /**
      Use a {@link Position}'s model {@link Matrix} to transform each
      {@link Vertex} from a {@link Model}'s coordinate system to the
      {@link Camera} coordinate system.

      @param vertexList   {@link List} of {@link Vertex} objects to transform into {@link Camera} coordinates
      @param modelMatrix  a {@link Position}'s transformation {@link Matrix}
   */
   public static void model2camera(List<Vertex> vertexList, Matrix modelMatrix)
   {
      // Mutate each Vertex object so that it contains camera coordinates.
      for (Vertex v : vertexList)
      {
         v.set( modelMatrix.times(v) );
      }
   }
}
