/**
   Our program IS the listener object. The important
   objects the listener needs access to are instance
   variables of a program object. We need a main()
   method to instantiate a program object.
*/

import renderer.gui.FrameBufferPanel;
import renderer.framebuffer.FrameBuffer;
import renderer.scene.*;
import renderer.models.Sphere;
import renderer.pipeline.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class InteractiveFrame_v3 implements KeyListener
{
   private FrameBufferPanel fbp = null; // Compare with InteractiveFrame_v2.
   private Scene scene = null;

   public InteractiveFrame_v3() // main() turns into a constructor!
   {
      FrameBuffer fb = new FrameBuffer(600, 600);
      fbp = new FrameBufferPanel(fb);
      JFrame jf = new JFrame("Interactive Frame with FrameBuffer");
      jf.add(fbp);
      jf.pack();
      jf.setVisible(true);
      jf.addKeyListener(this); // This InteractiveFrame_v3 object is the listener.

      scene = new Scene();
      Model model = new Sphere(1.0);
      scene.addModel(model);

      for (Vertex v : model.vertexList)
      {
         v.z -= 2.0;
      }

      Pipeline.render(scene, fb.vp);
      fbp.update();
   }//constructor


   // Implement the KeyListener interface.
   @Override public void keyPressed (KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped   (KeyEvent e)
   {
      System.out.println(e);
      for (Vertex v : scene.modelList.get(0).vertexList)
      {
         v.z -= 0.2;
      }
      fbp.getFrameBuffer().clearFB();
      Pipeline.render(scene, fbp.getFrameBuffer().vp);
      fbp.update();
   }


   public static void main(String[] args)
   {
      new InteractiveFrame_v3(); // Weird!
   }
}

/*
Here is a picture showing some relevant objects in the JVM's heap.

      JFrame object
+----------------------+                        InteractiveFrame_v3 object
|                      |       KeyListener      (is a KeyListener object)
|  List<KeyListener>---|------->+------+        +-------------------------+
|                      |        |      |        | FrameBufferPanel fbp    |
|                      |        +------+        | Scene scene             |
|  addKeyListener()    |        |  ----|------->|                         |
+----------------------+        +------+        | keyPressed(KeyEvent e)  |
an object that receives         |      |        | keyReleased(KeyEvent e) |
KeyEvent objects from           +------+        | keyTyped(KeyEvent e)    |
the JVM                                         |                         |
                                                +-------------------------+
                                                 an object that implements
                                                 the KeyListener interface
     KeyEvent object
   +-----------------+
   |  information    |        Scene object            FrameBufferPanel object
   |  from the OS    |      +-----------------+       +-----------------+
   |  about the      |      |  information    |       | pixel data for  |
   |  keyboard event |      |  about our 3D   |       | our rendered 3D |
   +-----------------+      |  graphics scene |       | graphics scene  |
                            +-----------------+       +-----------------+
*/
