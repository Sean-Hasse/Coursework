/*

*/

/**
   A library of predefined wireframe models.
*/
package renderer.models;
