/*

*/

/**
   Data structures for describing a 3D scene to the renderer.
*/
package renderer.scene;
