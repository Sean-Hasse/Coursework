/*

*/

import renderer.scene.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;
import renderer.gui.*;

import java.awt.Color;
import java.awt.event.*;
import javax.swing.JFrame;
import java.awt.BorderLayout;

/**
<pre>{@code
                   y
                   |
                   |
                   | v[4]
                 1 +-----------------+ v[5]=(1,1,0)
                  /|                /|
                /  |              /  |
              /    |            /    |
            /      |          /      |
      v[7] +-----------------+ v[6]  |
           |       |         |       |                    y
           |       |         |       |                    |
           |       |         |       | v[1]               |
           |  v[0] +---------|-------+------> x           |
           |      /          |      /1                    |
           |    /            |    /                       +-----> x
           |  /              |  /                        /
           |/                |/                         /
         1 +-----------------+                         /
         / v[3]=(0,0,1)      v[2]=(1,0,1)            z
       /
     /
    z
}</pre>
   Render a single wireframe cube.
*/
public class InteractiveCube_R2 implements KeyListener, ComponentListener
{
   private FrameBufferFrame fbf; // The event handlers need
   private Scene scene;          // access to these two fileds.

   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
   */
   public InteractiveCube_R2()
   {
      // Define initial dimensions for a FrameBuffer.
      final int fbWidth  = 512;
      final int fbHeight = 512;

      // Create a FrameBufferFrame holding a FrameBufferPanel.
      fbf = new FrameBufferFrame("Renderer 2", fbWidth, fbHeight);

      // Make this InteractiveCube_R2 object the event
      // handler for events from the FrameBufferFrame.
      fbf.addKeyListener(this);
      fbf.addComponentListener(this);


      // Create the Scene object that we shall render.
      scene = new Scene();

      // Create a Model object to hold the geometry.
      Model model = new Model("cube");

      // Add the Model to the Scene.
      scene.addModel(model);

      // Create the vertices for the Model.
      model.addVertex(new Vertex(0.0, 0.0, 0.0), // four vertices around the bottom face
                      new Vertex(1.0, 0.0, 0.0),
                      new Vertex(1.0, 0.0, 1.0),
                      new Vertex(0.0, 0.0, 1.0),
                      new Vertex(0.0, 1.0, 0.0), // four vertices around the top face
                      new Vertex(1.0, 1.0, 0.0),
                      new Vertex(1.0, 1.0, 1.0),
                      new Vertex(0.0, 1.0, 1.0));

      // Add the geometry to the Model.
      model.addLineSegment(new LineSegment(0, 1),  // bottom face
                           new LineSegment(1, 2),  // bottom face
                           new LineSegment(2, 3),  // bottom face
                           new LineSegment(3, 0),  // bottom face
                           new LineSegment(4, 5),  // top face
                           new LineSegment(5, 6),  // top face
                           new LineSegment(6, 7),  // top face
                           new LineSegment(7, 4),  // top face
                           new LineSegment(0, 4),  // back face
                           new LineSegment(1, 5),  // back face
                           new LineSegment(3, 7),  // front face
                           new LineSegment(2, 6)); // front face

      // Push the model away from where the camera is.
      for (Vertex v : model.vertexList)
      {
         v.z -= 2;
      }
   }


   // Implement the KeyListener interface.
   @Override public void keyPressed(KeyEvent e){}
   @Override public void keyReleased(KeyEvent e){}
   @Override public void keyTyped(KeyEvent e)
   {
      //System.out.println( e );

      char c = e.getKeyChar();
      if ('h' == c)
      {
         print_help_message();
         return;
      }
      else if ('d' == c)
      {
         Pipeline.debug = ! Pipeline.debug;
       //Rasterize_Clip.debug = ! Rasterize_Clip.debug;
      }
      else if ('c' == c)
      {
         Pipeline.doClipping = ! Pipeline.doClipping;
         System.out.print("Clipping is turned ");
         System.out.println(Pipeline.doClipping ? "On" : "Off");
      }
      else if ('p' == c)
      {
         scene.camera.perspective = ! scene.camera.perspective;
         String p = scene.camera.perspective ? "perspective" : "orthographic";
         System.out.println("Using " + p + " projection");
      }
      else if ('s' == c) // Scale the cube 10% smaller.
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.x /= 1.1;  // This does NOT work with
            v.y /= 1.1;  // perspective projection.
            v.z /= 1.1;
         }
      }
      else if ('S' == c) // Scale the cube 10% larger.
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.x *= 1.1;  // This does NOT work with
            v.y *= 1.1;  // perspective projection.
            v.z *= 1.1;
         }
      }
      else if ('x' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.x -= 0.1;
         }
      }
      else if ('X' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.x += 0.1;
         }
      }
      else if ('y' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.y -= 0.1;
         }
      }
      else if ('Y' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.y += 0.1;
         }
      }
      else if ('z' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.z -= 0.1;
         }
      }
      else if ('Z' == c)
      {
         for (Vertex v : scene.modelList.get(0).vertexList)
         {
            v.z += 0.1;
         }
      }

      // Render again.
      FrameBuffer fb = fbf.fbp.getFrameBuffer();
      fb.clearFB(Color.black);
      Pipeline.render(scene, fb.vp);
      fbf.fbp.update();
      fbf.repaint();
   }


   // Implement the ComponentListener interface.
   @Override public void componentMoved(ComponentEvent e){}
   @Override public void componentHidden(ComponentEvent e){}
   @Override public void componentShown(ComponentEvent e){}
   @Override public void componentResized(ComponentEvent e)
   {
      //System.out.println( e );

      // Get the new size of the FrameBufferPanel.
      int w = fbf.fbp.getWidth();
      int h = fbf.fbp.getHeight();

      // Create a new FrameBuffer that fits the new window size.
      FrameBuffer fb = new FrameBuffer(w, h);
      fb.clearFB(Color.black);
      Pipeline.render(scene, fb.vp);
      fbf.fbp.setFrameBuffer(fb);
      fbf.fbp.update();
      fbf.repaint();
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {
      print_help_message();

      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         new Runnable() // an anonymous inner class constructor
         {
            public void run() // implement the Runnable interface
            {
               // Call the constructor that builds the gui.
               new InteractiveCube_R2();
            }
         }
      );
   }


   private static void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off.");
      System.out.println("Use the 'p' key to toggle between parallel and orthographic projection.");
      System.out.println("Use the x/X, y/Y, z/Z, keys to translate the cube along the x, y, z axes.");
      System.out.println("Use the s/S keys to scale the size of the cube.");
      System.out.println("Use the 'c' key to toggle line clipping on and off.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }
}
