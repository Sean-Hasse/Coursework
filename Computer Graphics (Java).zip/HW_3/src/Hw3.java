/* Sean Hasse
   CS 455
   HW 3
*/

import renderer.scene.*;
import renderer.models.*;
import renderer.pipeline.*;
import renderer.framebuffer.*;
import renderer.gui.*;

import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;

/**

*/
public class Hw3
{
   /**
      This constructor instantiates the Scene object
      and initializes it with appropriate geometry.
   */
   public Hw3()
   {
      // Define initial dimensions for a FrameBuffer.
      final int fbWidth  = 1024;
      final int fbHeight = 1024;

      // Create a FrameBufferFrame holding a FrameBufferPanel.
      FrameBufferFrame fbf = new FrameBufferFrame("Renderer 2", fbWidth, fbHeight);
      fbf.setResizable(false);

      // Create the Scene object that we shall render
      Scene scene = new Scene();

      // Create several Model objects.
      scene.addModel(new Square(1));
      scene.addModel(new Square(2));
      scene.addModel(new Square(3));
      scene.addModel(new Circle(3, 4));
      scene.addModel(new Circle(3, 64));

      // Give each model a useful name.
      scene.modelList.get(0).name = "Square_1";
      scene.modelList.get(1).name = "Square_2";
      scene.modelList.get(2).name = "Square_3";
      scene.modelList.get(3).name = "Diamond";
      scene.modelList.get(4).name = "Circle";


      // Push the models away from where the camera is.
      for (Model m : scene.modelList)
      {
         for (Vertex v : m.vertexList)
         {
            v.z -= 10;
         }
      }

      // Give each model an initial position in the scene.
      for (Vertex v : scene.modelList.get(0).vertexList)
      {
         v.x += 0;
         v.y += 0;
      }
      for (Vertex v : scene.modelList.get(1).vertexList)
      {
         v.x -= 5;
         v.y -= 5;
      }
      for (Vertex v : scene.modelList.get(2).vertexList)
      {
         v.x += 5;
         v.y += 5;
      }
      for (Vertex v : scene.modelList.get(3).vertexList)
      {
         v.x += 5;
         v.y -= 5;
      }
      for (Vertex v : scene.modelList.get(4).vertexList)
      {
         v.x -= 5;
         v.y += 5;
      }

      // offset represents the pixels used by toolbars, may be different on different systems
      int offsetX = 7;
      int offsetY = 30;
      int[] centerX = new int[]{512 + offsetX, 256 + offsetX, 768 + offsetX, 768 + offsetX, 256 + offsetX};
      int[] centerY = new int[]{512 + offsetY, 768 + offsetY, 256 + offsetY, 768 + offsetY, 256 + offsetY};

       // an array for keeping track of which shapes are being dragged
       int[] moving = new int[]{0,0,0,0,0};

      // Render.
      FrameBuffer fb = fbf.fbp.getFrameBuffer();
      fb.clearFB(Color.black);
      Pipeline.render(scene, fb.vp);
      fbf.fbp.update();
      fbf.repaint();

      fbf.addMouseListener(
              new MouseListener()
              {
                 @Override public void mouseClicked(MouseEvent e){}
                 @Override public void mousePressed(MouseEvent e)
                 {
                     // distance of the click from center
                     double distance;

                     for (int i = 0; i < 5; i++) {

                         // test the squares first
                         if (i < 3) {
                             // find whether the difference in x or y is smaller
                             distance = Math.sqrt(Math.pow(e.getX() - centerX[i], 2) + Math.pow(e.getY() - centerY[i], 2));
                             int sideLength;
                             if (Math.abs(e.getX() - centerX[i]) < Math.abs(e.getY() - centerY[i]))
                                 sideLength = e.getX() - centerX[i];
                             else
                                 sideLength = e.getY() - centerY[i];

                             // use the pythagorean theorem for hit detection
                             if ((Math.pow(distance, 2) <= Math.pow(51.2 * (i + 1), 2) + Math.pow(sideLength, 2)))
                                 moving[i] = 1;
                             else
                                 moving[i] = 0;
                         }

                         // now test for the circles
                         else if(i < 5){
                             distance = Math.sqrt(Math.pow(e.getX() - centerX[i], 2) + Math.pow(e.getY() - centerY[i], 2));
                             if (distance <= 153.6)
                                 moving[i] = 1;
                             else
                                 moving[i] = 0;
                         }
                     }
                     System.out.println(moving[0] + " " + moving[1] + " " + moving[2] + " " + moving[3] + " " + moving[4]);
                 }
                 @Override public void mouseReleased(MouseEvent e)
                 {
                     // drop the shapes on release
                     for(int i = 0; i < 5; i++)
                         moving[i] = 0;

                     // Render again.
                     fb.clearFB(Color.black);
                     Pipeline.render(scene, fb.vp);
                     fbf.fbp.update();
                     fbf.repaint();
                 }
                 @Override public void mouseEntered(MouseEvent e){}
                 @Override public void mouseExited(MouseEvent e)
                 {
                     // drop the shapes on exit
                     for(int i = 0; i < 5; i++)
                         moving[i] = 0;

                     // Render again.
                     fb.clearFB(Color.black);
                     Pipeline.render(scene, fb.vp);
                     fbf.fbp.update();
                     fbf.repaint();
                 }
              });

      fbf.addMouseMotionListener(
              new MouseMotionListener()
              {
                  // hold on to the previous location of the mouse for distance
                  int prevX;
                  int prevY;
                 @Override public void mouseDragged(MouseEvent e)
                 {
                     // attributes
                     int distanceX;
                     int distanceY;

                     if(prevX == -25)
                         prevX = e.getX();
                     if(prevY == -25)
                         prevY = e.getY();

                     // find which shapes need to be moved
                     for (int i = 0; i < 5; i++) {
                         if(moving[i] == 1) {
                             // calculate the distance between previous position and current position
                             distanceX = e.getX() - prevX;
                             distanceY = e.getY() - prevY;

                             // move the center the appropriate amount
                             centerX[i] += distanceX;
                             centerY[i] += distanceY;

                             // convert the pixels to camera units, and move each vertex by that amount
                             for (Vertex v : scene.modelList.get(i).vertexList)
                             {
                                 v.x += (distanceX / 51.2);
                                 v.y -= (distanceY / 51.2);
                             }
                         }
                     }

                     // update previous position
                     prevX = e.getX();
                     prevY = e.getY();

                     // Render again.
                     fb.clearFB(Color.black);
                     Pipeline.render(scene, fb.vp);
                     fbf.fbp.update();
                     fbf.repaint();
                 }
                 @Override public void mouseMoved(MouseEvent e)
                 {
                     // reset the previous positions once its done
                     prevX = -25;
                     prevY = -25;
                 }
              });

      fbf.addKeyListener(
              new KeyListener()
              {
                 @Override public void keyTyped(KeyEvent e)
                 {
                    System.out.println(e);
                 }
                 @Override public void keyPressed(KeyEvent e){}
                 @Override public void keyReleased(KeyEvent e){}
              });
   }


   /**
      Create an instance of this class which has
      the affect of creating the GUI application.
   */
   public static void main(String[] args)
   {


      print_help_message();

      // We need to call the program's constructor in the
      // Java GUI Event Dispatch Thread, otherwise we get a
      // race condition between the constructor (running in
      // the main() thread) and the very first ComponentEvent
      // (running in the EDT).
      javax.swing.SwingUtilities.invokeLater(
         new Runnable() { // an anonymous inner class constructor
            public void run()
            { // implement the Runnable interface
               new Hw3(); // call the constructor that builds the gui
      }});
   }


   private static void print_help_message()
   {
      System.out.println("Use the 'd' key to toggle debugging information on and off.");
      System.out.println("Use the 'c' key to toggle line clipping on and off.");
      System.out.println("Use the 'h' key to redisplay this help message.");
   }



   // make a class that uses MouseListener
}
