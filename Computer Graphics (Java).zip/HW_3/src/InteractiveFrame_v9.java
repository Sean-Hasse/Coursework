/**
   The event handler object is an anonymous inner
   (nested) class of our program's constructor.
   The event handler object has access to the
   constructor's (final) local variables!
*/

import renderer.gui.FrameBufferPanel;
import renderer.framebuffer.FrameBuffer;
import renderer.scene.*;
import renderer.models.Sphere;
import renderer.pipeline.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class InteractiveFrame_v9
{
   public InteractiveFrame_v9() // main() turns into a constructor!
   {
      FrameBuffer fb = new FrameBuffer(600, 600);
      final FrameBufferPanel fbp = new FrameBufferPanel(fb);
      JFrame jf = new JFrame("Interactive Frame with FrameBuffer");
      jf.add(fbp);
      jf.pack();
      jf.setVisible(true);

      final Scene scene = new Scene(); // Put scene in the scope of the KeyListener.

      jf.addKeyListener(
         new KeyListener(){ // An anonymous local inner class constructor.
            // Implement the three methods of the KeyListener interface.
            @Override public void keyPressed (KeyEvent e){}
            @Override public void keyReleased(KeyEvent e){}
            @Override public void keyTyped   (KeyEvent e)
            {
               System.out.println(e);
               for (Vertex v : scene.modelList.get(0).vertexList)
               {
                  v.z -= 0.2;
               }
               fb.clearFB();
               Pipeline.render(scene, fb.vp);
               fbp.update();
            }
         }
      );

      Model model = new Sphere(1.0);
      scene.addModel(model);

      for (Vertex v : model.vertexList)
      {
         v.z -= 2.0;
      }

      Pipeline.render(scene, fb.vp);
      fbp.update();
   }//constructor


   public static void main(String[] args)
   {
      new InteractiveFrame_v9(); // Weird!
   }
}

/*
Here is a picture showing some relevant objects in the JVM's heap.

                                                InteractiveFrame_v9 constructor
                                                activation record of final local
                                                variables
                                                +----------------------------+
                                                | final FrameBufferPanel fbp |
                                                | final Scene scene          |
                                                |                            |
      JFrame object                             |                            |
+----------------------+                        +-----------/\---------------+
|                      |       KeyListener                  /\
|  List<KeyListener>---|------>>+------+                    || nesting link
|                      |        |      |                    ||  (closure)
|                      |        +------+        +-----------||------------+
|  addKeyListener()    |        |  ----|------>>|                         |
+----------------------+        +------+        | keyPressed(KeyEvent e)  |
an object that receives         |      |        | keyReleased(KeyEvent e) |
KeyEvent objects from           +------+        | keyTyped(KeyEvent e)    |
the JVM                                         |                         |
                                                +-------------------------+
                                                 an object that implements
                                                 the KeyListener interface
     KeyEvent object
   +-----------------+
   |  information    |        Scene object            FrameBufferPanel object
   |  from the OS    |      +-----------------+       +-----------------+
   |  about the      |      |  information    |       | pixel data for  |
   |  keyboard event |      |  about our 3D   |       | our rendered 3D |
   +-----------------+      |  graphics scene |       | graphics scene  |
                            +-----------------+       +-----------------+
*/
