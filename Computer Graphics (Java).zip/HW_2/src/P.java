/*

*/

import renderer.scene.*;

/**
   The letter P.
*/
public class P extends Model
{
   /**
      The letter P.
   */
   public P()
   {
      super("P");

      int n = 0; // number of vertices

      Vertex[] v = new Vertex[n];

      // Create vertices.
      Vertex v0 = new Vertex(0,0,0);
      Vertex v1 = new Vertex(.25,0,0);
      Vertex v2 = new Vertex(.25, .5, 0);
      Vertex v3 = new Vertex(.5, .5, 0);
      Vertex v4 = new Vertex(.25, .65, 0);
      Vertex v5 = new Vertex(.5, .65, 0);
      Vertex v6 = new Vertex(.7, .65, 0);
      Vertex v7 = new Vertex(.25, .85, 0);
      Vertex v8 = new Vertex(.5, .85, 0);
      Vertex v9 = new Vertex(.7, .85, 0);
      Vertex v10 = new Vertex(0, 1, 0);
      Vertex v11 = new Vertex(.5, 1, 0);

      Vertex v12 = new Vertex(0,0,-.25);
      Vertex v13 = new Vertex(.25,0,-.25);
      Vertex v14 = new Vertex(.25, .5, -.25);
      Vertex v15 = new Vertex(.5, .5, -.25);
      Vertex v16 = new Vertex(.25, .65, -.25);
      Vertex v17 = new Vertex(.5, .65, -.25);
      Vertex v18 = new Vertex(.7, .65, -.25);
      Vertex v19 = new Vertex(.25, .85, -.25);
      Vertex v20 = new Vertex(.5, .85, -.25);
      Vertex v21 = new Vertex(.7, .85, -.25);
      Vertex v22 = new Vertex(0, 1, -.25);
      Vertex v23 = new Vertex(.5, 1, -.25);

      addVertex(v0, v1, v2,v3,v4,v5,v6,v7,v8,v9,v10,v11);
      addVertex(v12,v13,v14,v15,v16,v17,v18,v19,v20,v21,v22,v23);

      // Create line segments.
      LineSegment l0 = new LineSegment(0,1);
      LineSegment l1 = new LineSegment(0,10);
      LineSegment l2 = new LineSegment(1,2);
      LineSegment l3 = new LineSegment(2,3);
      LineSegment l4 = new LineSegment(3,6);
      LineSegment l5 = new LineSegment(6,9);
      LineSegment l6 = new LineSegment(9,11);
      LineSegment l7 = new LineSegment(10,11);
      LineSegment l8 = new LineSegment(4,5);
      LineSegment l9 = new LineSegment(5,8);
      LineSegment l10 = new LineSegment(4,7);
      LineSegment l11 = new LineSegment(7,8);

      LineSegment l20 = new LineSegment(12,13);
      LineSegment l21 = new LineSegment(12,22);
      LineSegment l22 = new LineSegment(13,14);
      LineSegment l23 = new LineSegment(14,15);
      LineSegment l24 = new LineSegment(15,18);
      LineSegment l25 = new LineSegment(18,21);
      LineSegment l26 = new LineSegment(21,23);
      LineSegment l27 = new LineSegment(22,23);
      LineSegment l28 = new LineSegment(16,17);
      LineSegment l29 = new LineSegment(17,20);
      LineSegment l30 = new LineSegment(16,19);
      LineSegment l31 = new LineSegment(19,20);

      LineSegment l40 = new LineSegment(0,12);
      LineSegment l41 = new LineSegment(1,13);
      LineSegment l42 = new LineSegment(2,14);
      LineSegment l43 = new LineSegment(3,15);
      LineSegment l44 = new LineSegment(4,16);
      LineSegment l45 = new LineSegment(5,17);
      LineSegment l46 = new LineSegment(6,18);
      LineSegment l47 = new LineSegment(7,19);
      LineSegment l48 = new LineSegment(8,20);
      LineSegment l49 = new LineSegment(9,21);
      LineSegment l50 = new LineSegment(10,22);
      LineSegment l51 = new LineSegment(11,23);

      addLineSegment(l0,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11);
      addLineSegment(l20,l21,l22,l23,l24,l25,l26,l27,l28,l29,l30,l31);
      addLineSegment(l40,l41,l42,l43,l44,l45,l46,l47,l48,l49,l50,l51);

   }
}
