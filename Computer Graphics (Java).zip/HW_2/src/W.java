/*

*/

import renderer.scene.*;

/**
   The letter W.
*/
public class W extends Model
{
   /**
      The letter W.
   */
   public W()
   {
      super("W");

      int n = 0; // number of vertices

      Vertex[] v = new Vertex[n];

      // Create vertices.
      Vertex v0 = new Vertex(0,1,0);
      Vertex v1 = new Vertex(.2,1,0);
      Vertex v2 = new Vertex(.2,0,0);
      Vertex v3 = new Vertex(.4,0,0);
      Vertex v4 = new Vertex(.3,.25,0);
      Vertex v5 = new Vertex(.4,1,0);
      Vertex v6 = new Vertex(.6,1,0);
      Vertex v7 = new Vertex(.5,.75,0);
      Vertex v8 = new Vertex(.6,0,0);
      Vertex v9 = new Vertex(.8,0,0);
      Vertex v10 = new Vertex(.7,.25,0);
      Vertex v11 = new Vertex(.8, 1,0);
      Vertex v12 = new Vertex(1, 1, 0);

      Vertex v13 = new Vertex(0,1,-.25);
      Vertex v14 = new Vertex(.2,1,-.25);
      Vertex v15 = new Vertex(.2,0,-.25);
      Vertex v16 = new Vertex(.4,0,-.25);
      Vertex v17 = new Vertex(.3,.25,-.25);
      Vertex v18 = new Vertex(.4,1,-.25);
      Vertex v19 = new Vertex(.6,1,-.25);
      Vertex v20 = new Vertex(.5,.75,-.25);
      Vertex v21 = new Vertex(.6,0,-.25);
      Vertex v22 = new Vertex(.8,0,-.25);
      Vertex v23 = new Vertex(.7,.25,-.25);
      Vertex v24 = new Vertex(.8, 1,-.25);
      Vertex v25 = new Vertex(1, 1, -.25);

      addVertex(v0,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12);
      addVertex(v13, v14, v15, v16, v17, v18, v19, v20,v21,v22,v23,v24,v25);

      // Create line segments.
      LineSegment l0 = new LineSegment(0,1);
      LineSegment l1 = new LineSegment(0,2);
      LineSegment l2 = new LineSegment(2,3);
      LineSegment l3 = new LineSegment(1,4);
      LineSegment l4 = new LineSegment(4,5);
      LineSegment l5 = new LineSegment(5,6);
      LineSegment l6 = new LineSegment(3,7);
      LineSegment l7 = new LineSegment(7,8);
      LineSegment l8 = new LineSegment(6,10);
      LineSegment l9 = new LineSegment(8,9);
      LineSegment l10 = new LineSegment(9,12);
      LineSegment l11 = new LineSegment(10,11);
      LineSegment l12 = new LineSegment(11,12);

      LineSegment l20 = new LineSegment(13,14);
      LineSegment l21 = new LineSegment(13,15);
      LineSegment l22 = new LineSegment(15,16);
      LineSegment l23 = new LineSegment(14,17);
      LineSegment l24 = new LineSegment(17,18);
      LineSegment l25 = new LineSegment(18,19);
      LineSegment l26 = new LineSegment(16,20);
      LineSegment l27 = new LineSegment(20,21);
      LineSegment l28 = new LineSegment(19,23);
      LineSegment l29 = new LineSegment(21,22);
      LineSegment l30 = new LineSegment(22,25);
      LineSegment l31 = new LineSegment(23,24);
      LineSegment l32 = new LineSegment(24,25);

      LineSegment l40 = new LineSegment(0,13);
      LineSegment l41 = new LineSegment(1,14);
      LineSegment l42 = new LineSegment(2,15);
      LineSegment l43 = new LineSegment(3,16);
      LineSegment l44 = new LineSegment(4,17);
      LineSegment l45 = new LineSegment(5,18);
      LineSegment l46 = new LineSegment(6,19);
      LineSegment l47 = new LineSegment(7,20);
      LineSegment l48 = new LineSegment(8,21);
      LineSegment l49 = new LineSegment(9,22);
      LineSegment l50 = new LineSegment(10,23);
      LineSegment l51 = new LineSegment(11,24);
      LineSegment l52 = new LineSegment(12,25);


      addLineSegment(l0,l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12);
      addLineSegment(l20,l21,l22,l23,l24,l25,l26,l27,l28,l29,l30,l31,l32);
      addLineSegment(l40,l41,l42,l43,l44,l45,l46,l47,l48,l49,l50,l51,l52);
   }
}
