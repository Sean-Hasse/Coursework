/*

*/

/**
   Provides the renderer with an output data structure
   to hold the pixel values computed by the renderer.
*/
package framebuffer;
