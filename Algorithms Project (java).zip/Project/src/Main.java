/// Sean Hasse
/// Algorithms Project
/// 11/25/19

/// run time is n^2

import java.util.*;

public class Main {

    public static void main(String[] args)
    {
        // create the arrays that will hold the values of the weight and value of each item
        double[] weight = {3,4,5,11,1};
        double[] value  = {5,8,6,20,1};

        // set the maximum weight the backpack can carry
        int maxWeight = 23;

        // create the ratio array, a higher ratio is more optimal for storage
        double[] ratios = new double[weight.length];

        // create the totals array, which will have the amount of each item that will optimally fill the backpack
        int[] totals = new int[ratios.length];

        // fill the ratio array based on the values for 'value' and 'weight'
        for (int i = 0; i < weight.length; i++)
            ratios[i] = value[i] / weight[i];

        // call the backpack method and send it to the output
        String output = Arrays.toString(backpack(ratios, weight, value, totals, ratios.length, maxWeight));
        System.out.println(output);
    }


    // the backpack method recursively calls search to find the best ratio, then places as many of that item as allowed by maxWeight
    public static int[] backpack(double[] ratios, double[] weight, double[] value, int[] totals, int n, int max)
    {
        // find the current worst ratio, and change it to -1 so search will ignore it, until only the best ratio is left
        int worst = search(ratios);
        ratios[worst] = -1;

        // recursively call backpack
        if (n-1 != 0)
            backpack(ratios, weight, value, totals, n-1, max);

        // currentMax will keep track of how much weight we haven't used, by subtracting the amount already used in totals[]
        int currentMax = max;
        for(int i = 0; i < ratios.length-1; i++)
            currentMax -= totals[i] * weight[i];

        // use int division to find how many of the current item can fit into the bag, then return the value.
        totals[worst] = currentMax / (int)weight[worst];
        return totals;
    }

    // search will search the ratios array to find the worst non-negative ratio
    public static int search(double[] ratios)
    {
        // set attributes to default 0
        int worst = 0;
        double worstCompare = 0;

        for(int i = 0; i < ratios.length;i++)
        {
            // first, find the first non-negative ratio value and set it as worstCompare and its position as worst.
            // then compare worstCompare to all other values in ratio, set any worst ratios to be worstCompare and their position to worst
            if ((worstCompare == 0 && ratios[i] >=0) || ((ratios[i] < worstCompare) && ratios[i] != -1))
            {
                worstCompare = ratios[i];
                worst = i;
            }
        }
        return worst;
    }
}

